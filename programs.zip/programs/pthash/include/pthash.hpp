#pragma once

#include "encoders/encoders.hpp"
#include "single_phf.hpp"
#include "partitioned_phf.hpp"